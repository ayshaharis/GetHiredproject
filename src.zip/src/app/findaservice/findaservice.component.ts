import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-findaservice',
  templateUrl: './findaservice.component.html',
  styleUrls: ['./findaservice.component.css']
})
export class FindaserviceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
